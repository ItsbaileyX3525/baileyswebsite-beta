# Sus clicker V4

welcome to sus clicker V4

in this game you will click for sus... that's all...

Well you can buy more gens for more sus and buy will smith for double the current sus earnings and a cool transition.
